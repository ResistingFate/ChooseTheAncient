using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Godot;
using HarmonyLib;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.Events;
using MegaCrit.Sts2.Core.Helpers;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Events;
using MegaCrit.Sts2.Core.Random;
using MegaCrit.Sts2.Core.Rooms;
using MegaCrit.Sts2.Core.Runs;

namespace ChooseTheAncient.ChooseTheAncientCode;

public static class ChooseTheAncientHelpers
{
    private static readonly MethodInfo GenerateInitialOptionsWrapperMethod =
        AccessTools.Method(typeof(AncientEventModel), "GenerateInitialOptionsWrapper")
        ?? throw new InvalidOperationException("Could not locate AncientEventModel.GenerateInitialOptionsWrapper.");

    private static readonly FieldInfo EventOwnerBackingField =
        AccessTools.Field(typeof(EventModel), "<Owner>k__BackingField")
        ?? throw new InvalidOperationException("Could not locate EventModel owner backing field.");

    private static readonly FieldInfo EventRngBackingField =
        AccessTools.Field(typeof(EventModel), "<Rng>k__BackingField")
        ?? throw new InvalidOperationException("Could not locate EventModel RNG backing field.");

    public sealed class AncientPreviewData
    {
        public required AncientEventModel PreviewEvent { get; init; }
        public required IReadOnlyList<EventOption> Options { get; init; }
    }

    public static RunState? GetRunState(RunManager runManager)
    {
        return Traverse.Create(runManager)
            .Property("State")
            .GetValue<RunState>();
    }

    private static bool IsAncientValidForAct(AncientEventModel ancient, ActModel act)
    {
        /*
         * Made to handle CustomAncients in BaseLib without using BaseLib
         */
        MethodInfo? method = ancient.GetType().GetMethod(
            "IsValidForAct",
            BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
            binder: null,
            types: [typeof(ActModel)],
            modifiers: null);

        if (method == null || method.ReturnType != typeof(bool))
            return true;

        try
        {
            return (bool)method.Invoke(ancient, [act])!;
        }
        catch (Exception e)
        {
            ModLog.Error($"Failed to call IsValidForAct on {ancient.GetType().FullName}: {e}");
            return true;
        }
    }



    public static List<AncientEventModel> BuildCandidatePool(
        ActModel act,
        RunState runState,
        int targetActIndex,
        IReadOnlyList<int>? enabledSourceActsOverride = null)
    {
        List<AncientEventModel> defaultPool = BuildDefaultCandidatePool(act, runState);

        if (!ChooseTheAncientConfig.HasAncientPoolSourceActConfig(targetActIndex))
            return defaultPool;

        IReadOnlyList<int> enabledSourceActs = enabledSourceActsOverride
            ?? ChooseTheAncientConfig.GetEnabledAncientPoolSourceActs(targetActIndex);

        if (enabledSourceActs.Count == 0)
        {
            ModLog.Warn(
                $"No ancient source acts are enabled for act {targetActIndex + 1}; " +
                $"falling back to the default pool for {act.Id.Entry}.");
            return defaultPool;
        }

        List<AncientEventModel> filteredPool = BuildConfiguredCandidatePool(
            act,
            runState,
            targetActIndex,
            enabledSourceActs);

        if (filteredPool.Count == 0)
        {
            ModLog.Warn(
                $"Ancient source filters removed every candidate for act {targetActIndex + 1}; " +
                $"falling back to the default pool for {act.Id.Entry}.");
            return defaultPool;
        }

        LogPool(
            $"Act {targetActIndex + 1} configured source pool " +
            $"[{ChooseTheAncientConfig.DescribeAncientPoolSourceActs(enabledSourceActs)}]",
            filteredPool);

        return filteredPool;
    }

    private static List<AncientEventModel> BuildDefaultCandidatePool(ActModel targetAct, RunState runState)
    {
        List<AncientEventModel> sharedSubset = GetSharedAncientsValidForTargetAct(targetAct, runState);

        return targetAct
            .GetUnlockedAncients(runState.UnlockState)
            .Concat(sharedSubset)
            .DistinctBy(a => a.Id)
            .OrderBy(a => a.Id.Entry)
            .ToList();
    }

    private static List<AncientEventModel> BuildConfiguredCandidatePool(
        ActModel targetAct,
        RunState runState,
        int targetActIndex,
        IReadOnlyList<int> enabledSourceActs)
    {
        List<AncientEventModel> configuredPool = new();

        foreach (int sourceActIndex in enabledSourceActs)
        {
            if (sourceActIndex < 0 || sourceActIndex >= runState.Acts.Count)
            {
                ModLog.Warn(
                    $"Configured ancient source act {sourceActIndex + 1} is out of range for run state " +
                    $"while building act {targetActIndex + 1}'s pool.");
                continue;
            }

            ActModel sourceAct = runState.Acts[sourceActIndex];
            List<AncientEventModel> sourceActAncients = sourceAct
                .GetUnlockedAncients(runState.UnlockState)
                .Where(ancient => IsAncientValidForAct(ancient, targetAct))
                .ToList();

            LogPool(
                $"Act {targetActIndex + 1} source act {sourceActIndex + 1} candidates",
                sourceActAncients);

            configuredPool.AddRange(sourceActAncients);
        }

        configuredPool.AddRange(GetSharedAncientsValidForTargetAct(targetAct, runState));

        return configuredPool
            .DistinctBy(a => a.Id)
            .OrderBy(a => a.Id.Entry)
            .ToList();
    }

    private static List<AncientEventModel> GetSharedAncientsValidForTargetAct(ActModel targetAct, RunState runState)
    {
        if (!runState.UnlockState.SharedAncients.Any())
            ModLog.Debug("runState.UnlockState.SharedAncients is empty");

        List<AncientEventModel> sharedSubset = runState.UnlockState.SharedAncients
            .Where(ancient => IsAncientValidForAct(ancient, targetAct))
            .ToList();

        if (ModLog.IsDebugEnabled)
        {
            string sharedPool = string.Join(",", sharedSubset.Select(ancient => ancient.Id.Entry));
            ModLog.Debug($"Shared ancients valid for {targetAct.Id.Entry}: {sharedPool}");
        }

        return sharedSubset;
    }
    
    public static List<AncientEventModel> LimitCandidatePoolForVote(
        RunState runState,
        int nextActIndex,
        List<AncientEventModel> pool, int ancientCount)
    {
        /*
         * Takes runstate, and act index, and available ancients, and number of ancients to return
         * Returns the list of ancients that will be used be the ancient ban selection screen
         */
        if (pool.Count <= ancientCount)
        {
            return pool;
        }

        if (pool.Count < ancientCount)
        {
            ancientCount = pool.Count;
        }

        List<AncientEventModel> shuffled = pool.ToList();
        var rng = CreateDisplayedPoolRng(runState, nextActIndex);
        rng.Shuffle(shuffled);

        List<AncientEventModel> limited = shuffled
            .Take(ancientCount)
            .ToList();

        LogPool($"Act {nextActIndex + 1} limited ballot", limited);
        return limited;
    }

    public static void SetChosenAncient(ActModel act, AncientEventModel chosenAncient)
    {
        RoomSet? rooms = Traverse.Create(act)
            .Field("_rooms")
            .GetValue<RoomSet>();

        if (rooms == null)
        {
            throw new InvalidOperationException("Could not get act RoomSet.");
        }

        rooms.Ancient = chosenAncient;
    }

    public static Rng CreateDisplayedPoolRng(RunState runState, int nextActIndex)
    {
        return new Rng(runState.Rng.Seed, $"choose_the_ancient_display_pool_act_{nextActIndex}");
    }

    public static Rng CreateEliminationResolutionRng(RunState runState, int nextActIndex)
    {
        return new Rng(runState.Rng.Seed, $"choose_the_ancient_elimination_vote_act_{nextActIndex}");
    }

    public static Rng CreateFinalVoteResolutionRng(RunState runState, int nextActIndex)
    {
        return new Rng(runState.Rng.Seed, $"choose_the_ancient_final_vote_act_{nextActIndex}");
    }

    public static Rng CreateSecondRoundPresentationRng(RunState runState, int nextActIndex)
    {
        return new Rng(runState.Rng.Seed, $"choose_the_ancient_second_vote_presentation_act_{nextActIndex}");
    }
    
    public static Rng CreateAncientRelicOptionsRng(RunState runstate, int nextActIndex, ulong player, string ancient)
    {
        return new Rng(runstate.Rng.Seed, $"choose_the_ancient_relic_options_{nextActIndex}_{ancient}_{player}");
    }
    
    public static uint ComputeVanillaEventSeed(RunState runState, Player player, EventModel eventModel)
    {
        /*
         * Goal here is to copy the RNG method vanilla uses, so it'll be the same as when the ancient
         * reveals the reward
         */
        ulong ownerContribution = eventModel.IsShared ? 0UL : player.NetId;

        return unchecked((uint)(
            runState.Rng.Seed
            + ownerContribution
            + (ulong)StringHelper.GetDeterministicHashCode(eventModel.Id.Entry)));
    }

    public static Rng CreatePreviewEventRng(RunState runState, Player player, EventModel eventModel)
    {
        return new Rng(ComputeVanillaEventSeed(runState, player, eventModel));
    }

    public static Dictionary<string, AncientPreviewData> BuildPreviewDataByAncientId(
        Player player,
        IEnumerable<AncientEventModel> ancients,
        int nextActIndex)
    {
        Dictionary<string, AncientPreviewData> previews = new();

        foreach (AncientEventModel ancient in ancients)
        {
            // Weird situations where I couldn't find the Ancient options so cased in double try block
            AncientPreviewData? preview = TryGeneratePreviewData(player, ancient, nextActIndex);
            if (preview != null)
            {
                previews[ancient.Id.Entry] = preview;
            }
        }

        return previews;
    }

    public static AncientPreviewData? TryGeneratePreviewData(
        Player player,
        AncientEventModel ancient,
        int nextActIndex)
    {
        /* simulate the next act, and what the relic options are going to be.*/ 
        try
        {
            AncientEventModel previewEvent = (AncientEventModel)ancient.ToMutable();
            RunState runState = player.RunState as RunState;
            int originalActIndex = runState.CurrentActIndex;

            try
            {
                runState.CurrentActIndex = nextActIndex;
                EventOwnerBackingField.SetValue(previewEvent, player);
                // I want to experiment with the relics rewards for all players being a shared event being a shared
                // pool. Shared pools should have the same RNG for each player, where as independent offerings
                // should have Rng based on their player ID.
                /*
                 * TODO implement patches so ancient events can be shared
                 */
                Rng previewRng = CreatePreviewEventRng(runState, player, previewEvent);
                //Rng previewRng = CreateAncientRelicOptionsRng(
                //    runState, nextActIndex, (GroupAncientOptionsPool ? 0UL : player.NetId), previewEvent.Id.Entry);
                // We use are new rng to change how the ancients randomness work and don't change it back
                EventRngBackingField.SetValue(previewEvent, previewRng);

                ModLog.Debug($"Generating preview data for {ancient.Id.Entry} with preview seed {previewRng.Seed} for player {player.NetId} at act index {nextActIndex}.");

                // This is what BeginEvents does in Megacritic EventModel
                previewEvent.CalculateVars();

                IReadOnlyList<EventOption> options =
                    (GenerateInitialOptionsWrapperMethod.Invoke(previewEvent, Array.Empty<object>()) as IReadOnlyList<EventOption>)
                    ?? Array.Empty<EventOption>();

                LogPreviewOptions(previewEvent, ancient, options);

                return new AncientPreviewData
                {
                    PreviewEvent = previewEvent,
                    Options = options.ToList(),
                };
            }
            finally
            {
                runState.CurrentActIndex = originalActIndex;
            }
        }
        catch (Exception ex)
        {
            ModLog.Error($"Failed to generate preview data for ancient {ancient.Id.Entry}: {ex}");
            return null;
        }
    }

    public static bool GroupAncientOptionsPool { get; set; } = false;

    // Log stuff below

    private static string SafeFormatLoc(LocString? loc)
    {
        if (loc == null)
        {
            return "<null>";
        }

        try
        {
            return loc.GetFormattedText();
        }
        catch (Exception ex)
        {
            return $"<loc format failed: {ex.GetType().Name}>";
        }
    }

    private static void LogPreviewOptions(AncientEventModel previewEvent, AncientEventModel ancient, IReadOnlyList<EventOption> options)
    {
        if (!ModLog.IsDebugEnabled)
            return;

        ModLog.Debug($"Preview options for {ancient.Id.Entry}: count={options.Count}");

        if (!ModLog.IsTraceEnabled)
            return;

        for (int i = 0; i < options.Count; i++)
        {
            EventOption option = options[i];
            try
            {
                previewEvent.DynamicVars.AddTo(option.Title);
                previewEvent.DynamicVars.AddTo(option.Description);
            }
            catch
            {
            }

            string relicId = option.Relic?.Id.Entry ?? "<none>";
            string relicTitle = option.Relic != null ? SafeFormatLoc(option.Relic.Title) : "<none>";
            string title = SafeFormatLoc(option.Title);
            string description = SafeFormatLoc(option.Description);

            ModLog.Trace($"  [{i}] textKey={option.TextKey}, relicId={relicId}, relicTitle={relicTitle}, title={title}, description={description}");
        }
    }

    public static string DescribeAncients(IEnumerable<AncientEventModel> ancients)
    {
        return string.Join(", ", ancients.Select(a => $"{a.Id.Entry} ({a.Title.GetFormattedText()})"));
    }

    public static void LogPool(string context, IEnumerable<AncientEventModel> ancients)
    {
        if (!ModLog.IsDebugEnabled)
            return;

        ModLog.Debug($"{context}: {DescribeAncients(ancients)}");
    }
    
    
}
